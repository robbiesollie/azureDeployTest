CREATE TRIGGER exclusive_admin_pprov ON problem_provider AFTER INSERT
AS
BEGIN
	IF(EXISTS (SELECT adminID FROM system_admin WHERE adminID IN(SELECT pproviderID FROM INSERTED))) BEGIN
	ROLLBACK;
END
END
go

