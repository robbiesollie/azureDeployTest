CREATE TRIGGER exclusive_admin_sprov ON solution_providers AFTER INSERT
AS
BEGIN
	IF(EXISTS (SELECT adminID FROM system_admin WHERE adminID IN(SELECT sproviderID FROM INSERTED))) BEGIN
	ROLLBACK;
END
END
GO

