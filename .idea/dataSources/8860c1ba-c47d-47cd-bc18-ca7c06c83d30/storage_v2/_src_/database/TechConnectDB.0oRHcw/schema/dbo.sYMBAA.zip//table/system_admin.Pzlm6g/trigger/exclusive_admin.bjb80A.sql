CREATE TRIGGER exclusive_admin ON system_admin AFTER INSERT
AS
BEGIN
	IF(EXISTS (SELECT sproviderID FROM solution_providers WHERE sproviderID IN(SELECT adminID FROM INSERTED))
	OR EXISTS (SELECT pproviderID FROM problem_provider WHERE pproviderID IN(SELECT adminID FROM INSERTED))) BEGIN
	ROLLBACK;
END
END
GO

